const Blog = require('../models/Blog');


// Create a new blog
const createBlog = async (req, res) => {
    const { title, content } = req.body;
    if (!title || !content) return res.status(400).json({ message: 'Title and content are required' });

    try {
        const newBlog = new Blog({
            title,
            content,
            createdBy: req.user?.email,
            lastEditedBy: req.user?.email,
            lockedBy: null,
            lockedAt: null
        });

        const savedBlog = await newBlog.save();
        res.status(201).json(savedBlog);
    } catch (error) {
        console.log(error, "error");
        res.status(500).json({ message: 'Failed to create blog' });
    }
};

// Get all blogs
const getAllBlogs = async (req, res) => {
    try {
        const blogs = await Blog.find();
        res.json(blogs);
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch blogs' });
    }
};

// Get a specific blog
const getBlogById = async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);
        if (!blog) return res.status(404).json({ message: 'Blog not found' });
        res.json(blog);
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch blog' });
    }
};

// Edit a blog
const editBlog = async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);
        if (!blog) return res.status(404).json({ message: 'Blog not found' });
        const { title, content } = req.body;
        if (!title || !content) return res.status(400).json({ message: 'Title and content are required' });


        if (blog.isLocked && blog.lockedBy.toString() !== req.user.email) {
            return res.status(403).json({ message: 'Blog is locked by another user' });
        }

        blog.title = title;
        blog.content = content;
        blog.lastEditedBy = req.user.email;
        blog.isLocked = true;
        blog.lockedBy = req.user.email;
        blog.lockedAt = new Date();

        await blog.save();
        res.json(blog);
    } catch (error) {
        console.log("Error saving blog", error);
        res.status(500).json({ message: 'Failed to update blog' });
    }
};

// Unlock a blog
const unlockBlog = async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id);
        if (!blog) return res.status(404).json({ message: 'Blog not found' });

        if (blog.lockedBy.toString() !== req.user.email) {
            return res.status(403).json({ message: 'You are not authorized to unlock this blog' });
        }

        blog.isLocked = false;
        blog.lockedBy = null;
        blog.lockedAt = null;

        await blog.save();
        res.json({ message: 'Blog unlocked successfully' });
    } catch (error) {
        console.log("Error: " + error)
        res.status(500).json({ message: 'Failed to unlock blog' });
    }
};

const deleteBlog = async (req, res) => {
    const { id } = req.params;
    try {
        // Find the blog by ID
        const blog = await Blog.findById(id);
        if (!blog) {
            return res.status(404).json({ message: 'Blog not found' });
        }
        await Blog.findByIdAndDelete(id);
        res.status(200).json({ message: 'Blog deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Failed to delete blog' });
    }
};

module.exports = {
    createBlog,
    getAllBlogs,
    getBlogById,
    editBlog,
    unlockBlog,
    deleteBlog
};
