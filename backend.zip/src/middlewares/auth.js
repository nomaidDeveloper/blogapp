const jwt = require('jsonwebtoken');

const createToken = (email) => {
    try {
        const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1d' })
        return token;
    } catch (error) {
        throw error;
    }
};
// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
    const token = req.body.token || req.query.token || req.headers["x-access-token"] || req.headers["authorization"];
    if (!token) {
        return res.status(403).json({ status: MESSAGE.Failed, message: 'A token is required for authentication' });
    }
    const tokenWithoutBearer = token.replace(/^Bearer\s+/i, '');
    try {
        const verified = jwt.verify(tokenWithoutBearer,process.env.JWT_SECRET);
        req.user = verified;
        next();
    } catch (error) {
        res.status(400).json({ message: 'Invalid token.' });
    }
};

module.exports = { verifyToken, createToken };
