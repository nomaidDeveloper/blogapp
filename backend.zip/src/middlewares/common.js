const bcrypt = require('bcryptjs');

const encryptPass = async (dPassword) => {
    try {
        const saltRounds = 10;

        // Generate the hash using bcrypt.hash
        const hash = await bcrypt.hash(dPassword, saltRounds);

        // Return the generated hash
        return hash;
    } catch (error) {
        // Handle any errors that occur during the hashing process
        console.log(error);
        throw error;
    }
};

const bycryptPass = async (userPassword, hashedPassword) => {
    try {
        const match = await bcrypt.compare(userPassword, hashedPassword);

        if (match) {
            // Passwords match
            console.log('Passwords match');
        } else {
            // Passwords do not match
            console.log('Passwords do not match');
        }

        return match;
    } catch (error) {
        // Handle any errors that occur during the comparison process
        console.log(error);
        throw error;
    }
};

module.exports = { encryptPass, bycryptPass };
