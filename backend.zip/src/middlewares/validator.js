function validateEmailAndPassword(req, res, next) {
  try {
    const { email, password } = req.body || req.params || req.query;

    if (!email) {
      throw new Error('Email is required');
    }

    if (!password) {
      throw new Error("Password is required");
    }

    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,6}$/;
    if (!email.match(emailRegex)) {
      throw new Error("Email is not a valid email");
    }

    next();
  } catch (error) {
    console.error('Error:', error);
    res.status(400).json({ message: error.message });
  }
}

module.exports = {
  validateEmailAndPassword
};
