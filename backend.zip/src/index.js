const dotenv = require('dotenv');
dotenv.config();
const express = require('express');
const cors = require('cors');
const { connectMyDb } = require('./config/db.js');
const router = require('./routes/index.js');

const app = express();
const PORT = process.env.PORT || 8000;

// Connect to MongoDB
connectMyDb();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api', router);

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
