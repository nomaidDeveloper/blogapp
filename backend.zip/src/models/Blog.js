const mongoose = require('mongoose');

// Define the blog schema
const blogSchema = new mongoose.Schema(
    {
        title: { type: String, required: true },
        content: { type: String, required: true },
        lastEditedBy:String,
        isLocked: { type: Boolean, default: false },
        lockedBy:String,
        lockedAt:Date
    },
    { timestamps: true }
);

// Create the blog model based on the blog schema
const Blog = mongoose.model('Blog', blogSchema);
module.exports = Blog;
