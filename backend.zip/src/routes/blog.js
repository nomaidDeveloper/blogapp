const express = require('express');
const BlogController = require('../controllers/blogController');
const { verifyToken } = require('../middlewares/auth');

const router = express.Router();


router.use(verifyToken);
router.post('/create', BlogController.createBlog);
router.get('/list', BlogController.getAllBlogs);
router.get('/:id', BlogController.getBlogById);
router.put('/:id', BlogController.editBlog);
router.post('/:id/unlock', BlogController.unlockBlog);
router.delete('/:id', BlogController.deleteBlog);

module.exports = router;
