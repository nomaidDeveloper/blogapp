const express = require('express');
const authRouter = require('./auth.js');
const BlogRouter = require('./blog.js'); 

const router = express.Router();

// Mount the auth router on the '/auth' path
router.use('/auth', authRouter);
router.use('/blog', BlogRouter);

module.exports = router;