const express = require('express');
const UserController = require('../controllers/authController.js');
const { validateEmailAndPassword } = require('../middlewares/validator.js');

const router = express.Router();

router.post('/signup', validateEmailAndPassword, UserController.signup);
router.post('/login', validateEmailAndPassword, UserController.login);

module.exports = router;