// const chai = require('chai');
// const expect = chai.expect;
// const sinon = require('sinon');
// const User = require('../src/models/user')
// const { encryptPass } = require('../src/middlewares/common');
// const app = require('../src/index')

// describe('Signup', () => {
//   let findOneStub, saveStub, encryptPassStub;

//   beforeEach(() => {
//     findOneStub = sinon.stub(User, 'findOne');
//     saveStub = sinon.stub(User.prototype, 'save');
//     encryptPassStub = sinon.stub(encryptPass, 'encrypt').resolves('encryptedPassword'); // Adjust if encryptPass has a method to encrypt
//   });

//   afterEach(() => {
//     findOneStub.restore();
//     saveStub.restore();
//     encryptPassStub.restore();
//   });

//   it('should register a new user', async () => {
//     findOneStub.resolves(null);
//     saveStub.resolves({ email: 'test@example.com', password: 'encryptedPassword' });

//     const res = await chai.request(app)
//       .post('/api/auth/signup')
//       .send({ email: 'test@example.com', password: 'password123' });

//     expect(res).to.have.status(201);
//     expect(res.body).to.have.property('success', true);
//     expect(res.body.data).to.have.property('email', 'test@example.com');
//   });

//   it('should return 400 if user already exists', async () => {
//     findOneStub.resolves({ email: 'test@example.com' });

//     const res = await chai.request(app)
//       .post('/api/auth/signup')
//       .send({ email: 'test@example.com', password: 'password123' });

//     expect(res).to.have.status(400);
//     expect(res.body).to.have.property('success', false);
//     expect(res.body).to.have.property('message', 'User already exists.');
//   });

//   it('should return 500 if an error occurs', async () => {
//     findOneStub.rejects(new Error('Database error'));

//     const res = await chai.request(app)
//       .post('/api/auth/signup')
//       .send({ email: 'test@example.com', password: 'password123' });

//     expect(res).to.have.status(500);
//     expect(res.body).to.have.property('success', false);
//     expect(res.body).to.have.property('message', 'Failed to create user.');
//   });
// });
