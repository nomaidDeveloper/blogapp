import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, Link } from 'react-router-dom';
import { fetchBlog } from '../store/blogSlice';

function BlogDetail() {
    const { id } = useParams();
    const dispatch = useDispatch();
    const { currentBlog, loading, error } = useSelector((state) => state.blog);

    useEffect(() => {
        dispatch(fetchBlog(id));
    }, [dispatch, id]);

    if (loading) return <div>Loading...</div>;
    const errorMessage = error ? (
        <div className="error-message">
            {error.message || "An unknown error occurred"}
        </div>
    ) : null;
    if (error) return <div className="error">Error: {errorMessage}</div>;
    if (!currentBlog) return null;

    return (
        <div className="centered-content">
            <div className="blog-create-container">
                <h2>{currentBlog.title}</h2>
                <p>{currentBlog.content}</p>
                <div className="button-container">
                    <Link to={`/editblog/${id}`} className="btn btn-primary">Edit</Link>
                    <Link to="/" className="btn btn-secondary">Back to List</Link>
                </div>
            </div>
        </div>
    );
}

export default BlogDetail;