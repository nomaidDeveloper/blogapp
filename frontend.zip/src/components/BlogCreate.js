import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { createBlog } from '../store/blogSlice';

function BlogCreate() {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const resultAction = await dispatch(createBlog({ title, content }));
        if (createBlog.fulfilled.match(resultAction)) {
            navigate('/');
        }
    };

    return (
        <div className="centered-content">
            <div className="blog-create-container">
                <h2>Create New Blog</h2>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="title">Title:</label>
                        <input
                            type="text"
                            id="title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="content">Content:</label>
                        <textarea
                            id="content"
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit">Create Blog</button>
                </form>
            </div>
        </div>

    );
}

export default BlogCreate;