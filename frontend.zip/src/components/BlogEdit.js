import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchBlog, updateBlog, unlockBlog } from '../store/blogSlice';

function BlogEdit() {
    const { id } = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { currentBlog, loading, error } = useSelector((state) => state.blog);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');

    useEffect(() => {
        dispatch(fetchBlog(id));
    }, [dispatch, id]);

    useEffect(() => {
        if (currentBlog) {
            setTitle(currentBlog.title);
            setContent(currentBlog.content);
        }
    }, [currentBlog]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const resultAction = await dispatch(updateBlog({ id, blogData: { title, content } }));
        if (updateBlog.fulfilled.match(resultAction)) {
            navigate('/');
        }
    };

    const handleUnlock = async () => {
        await dispatch(unlockBlog(id));
        dispatch(fetchBlog(id));
    };

    if (loading) return <div>Loading...</div>;
    const errorMessage = error ? (
        <div className="error-message">
            {error.message || "An unknown error occurred"}
        </div>
    ) : null;
    if (error) return <div className="error">Error: {errorMessage}</div>;
    if (!currentBlog) return null;

    return (
        <div className="centered-content">
            <div className="blog-create-container">
                <h2>Edit Blog</h2>
                {currentBlog.isLocked && (
                    <p>This blog is currently locked. Only the user who locked it can edit.</p>
                )}
                <form onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="title">Title:</label>
                        <input
                            type="text"
                            id="title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            disabled={currentBlog.isLocked}
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="content">Content:</label>
                        <textarea
                            id="content"
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            disabled={currentBlog.isLocked}
                            required
                        />
                    </div>
                    <button type="submit" disabled={currentBlog.isLocked}>Save</button>
                </form>
                {currentBlog.isLocked && <button onClick={handleUnlock}>Unlock</button>}
            </div>
        </div>

    );
}

export default BlogEdit;