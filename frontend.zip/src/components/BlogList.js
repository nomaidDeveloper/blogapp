// Example BlogList component with error handling
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { fetchBlogs, deleteBlog } from '../store/blogSlice';
import { Table, Button } from 'react-bootstrap';
import { logout } from '../store/authSlice';

function BlogList() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { blogs, loading, error } = useSelector((state) => state.blog);

    useEffect(() => {
        dispatch(fetchBlogs());
    }, [dispatch]);

    const handleDelete = (id) => {
        if (window.confirm('Are you sure you want to delete this blog?')) {
            dispatch(deleteBlog(id));
        }
    };
    const handleLogout = () => {
        dispatch(logout());
        navigate('/login'); // Redirect to login page after logout
    };
    const handleEdit = (id) => {
        window.location.href = `/editblog/${id}`;
    };

    if (loading) return <div>Loading...</div>;

    const errorMessage = error ? (
        <div className="error-message">
            {error.message || "An unknown error occurred"}
        </div>
    ) : null;

    return (
        <div>
            <div className="header-container">
                <h2>Blog List</h2>
                <div>
                    <Button as={Link} to="/createblog" variant="primary">
                        Create New Blog
                    </Button>
                    <Button onClick={handleLogout} variant="primary">Logout</Button>
                </div>

            </div>
            {errorMessage}
            {blogs.length === 0 ? (
                <p>No blogs available.</p>
            ) : (
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Content</th>
                            <th>Created At</th>
                            <th>Actions</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {blogs.map((blog) => (
                            <tr key={blog._id}>
                                <td>
                                    <Link to={`/blog/${blog._id}`}>{blog.title}</Link>
                                </td>
                                <td>
                                    <div>{blog.content}</div>
                                </td>
                                <td>{new Date(blog.createdAt).toLocaleDateString()}</td>
                                <td>
                                    <Button variant="primary" onClick={() => handleEdit(blog._id)}>
                                        Edit
                                    </Button>
                                </td>
                                <td>
                                    <Button variant="danger" onClick={() => handleDelete(blog._id)}>
                                        Delete
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            )}
        </div>
    );
}

export default BlogList;
