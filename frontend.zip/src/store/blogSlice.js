import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../helper/axiosInstance';

// Create a new blog
export const createBlog = createAsyncThunk(
  'blog/create',
  async (blogData, { getState, rejectWithValue }) => {
    try {
      const { auth } = getState();
      const response = await axiosInstance.post('/api/blog/create', blogData, {
        headers: { Authorization: auth.token }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to create blog');
    }
  }
);

// Fetch all blogs
export const fetchBlogs = createAsyncThunk(
  'blog/list',
  async (_, { getState, rejectWithValue }) => {
    try {
      const { auth } = getState();
      const response = await axiosInstance.get('/api/blog/list', {
        headers: { Authorization: auth.token }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch blogs');
    }
  }
);

// Fetch a single blog by ID
export const fetchBlog = createAsyncThunk(
  'blog/getById',
  async (id, { getState, rejectWithValue }) => {
    try {
      const { auth } = getState();
      const response = await axiosInstance.get(`/api/blog/${id}`, {
        headers: { Authorization: auth.token }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to fetch blog');
    }
  }
);

// Update a blog
export const updateBlog = createAsyncThunk(
  'blog/update',
  async ({ id, blogData }, { getState, rejectWithValue }) => {
    try {
      const { auth } = getState();
      const response = await axiosInstance.put(`/api/blog/${id}`, blogData, {
        headers: { Authorization: auth.token }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to update blog');
    }
  }
);

// Unlock a blog
export const unlockBlog = createAsyncThunk(
  'blog/unlock',
  async (id, { getState, rejectWithValue }) => {
    try {
      const { auth } = getState();
      const response = await axiosInstance.post(`/api/blog/${id}/unlock`, {}, {
        headers: { Authorization: auth.token }
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to unlock blog');
    }
  }
);

// Delete a blog
export const deleteBlog = createAsyncThunk(
  'blog/delete',
  async (id, { getState, rejectWithValue }) => {
    try {
      const { auth } = getState();
      await axiosInstance.delete(`/api/blog/${id}`, {
        headers: { Authorization: auth.token }
      });
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data || 'Failed to delete blog');
    }
  }
);

const blogSlice = createSlice({
  name: 'blog',
  initialState: {
    blogs: [],
    currentBlog: null,
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchBlogs.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchBlogs.fulfilled, (state, action) => {
        state.loading = false;
        state.blogs = action.payload; // Ensure this matches your response structure
      })
      .addCase(fetchBlogs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(fetchBlog.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchBlog.fulfilled, (state, action) => {
        state.loading = false;
        state.currentBlog = action.payload;
      })
      .addCase(fetchBlog.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createBlog.fulfilled, (state, action) => {
        state.blogs.push(action.payload);
      })
      .addCase(createBlog.rejected, (state, action) => {
        state.error = action.payload;
      })
      .addCase(updateBlog.fulfilled, (state, action) => {
        const index = state.blogs.findIndex(blog => blog._id === action.payload._id);
        if (index !== -1) {
          state.blogs[index] = action.payload;
        }
        if (state.currentBlog && state.currentBlog._id === action.payload._id) {
          state.currentBlog = action.payload;
        }
      })
      .addCase(updateBlog.rejected, (state, action) => {
        state.error = action.payload;
      })
      .addCase(unlockBlog.fulfilled, (state, action) => {
        if (state.currentBlog && state.currentBlog._id === action.payload._id) {
          state.currentBlog.isLocked = false;
        }
      })
      .addCase(unlockBlog.rejected, (state, action) => {
        state.error = action.payload;
      })
      .addCase(deleteBlog.fulfilled, (state, action) => {
        state.blogs = state.blogs.filter(blog => blog._id !== action.payload);
        if (state.currentBlog && state.currentBlog._id === action.payload) {
          state.currentBlog = null;
        }
      })
      .addCase(deleteBlog.rejected, (state, action) => {
        state.error = action.payload;
      });
  }
});

export default blogSlice.reducer;
