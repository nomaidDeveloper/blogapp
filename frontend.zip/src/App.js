import React from 'react';
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Login from './components/Login';
import BlogList from './components/BlogList';
import BlogEdit from './components/BlogEdit';
import Signup from './components/SignupPage';
import ProtectedRoute from './components/ProtectedRoute';
import './styles.css'; 
import NotFound from './components/NotFound';
import BlogCreate from './components/BlogCreate';
import BlogDetail from './components/BlogDetail';
const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/signup",
    element: <Signup />,
  },
  {
    path: "/",
    element: <ProtectedRoute><BlogList /></ProtectedRoute>,
  },
  {
    path: "/editblog/:id",
    element: <ProtectedRoute><BlogEdit /></ProtectedRoute>,
  },
  {
    path: "/createblog",
    element: <ProtectedRoute><BlogCreate /></ProtectedRoute>,
  },
  {
    path: "/blog/:id",
    element: <ProtectedRoute><BlogDetail /></ProtectedRoute>,
  },
  {
    path: "*", 
    element: <NotFound />
  },
]);

function App() {
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;